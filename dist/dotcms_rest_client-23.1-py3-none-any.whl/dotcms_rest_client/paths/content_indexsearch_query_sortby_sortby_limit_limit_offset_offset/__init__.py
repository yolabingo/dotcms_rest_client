# do not import all endpoints into this module because that uses a lot of memory and stack frames
# if you need the ability to import all endpoints from this module, import them with
# from dotcms_rest_client.paths.content_indexsearch_query_sortby_sortby_limit_limit_offset_offset import Api

from dotcms_rest_client.paths import PathValues

path = PathValues.CONTENT_INDEXSEARCH_QUERY_SORTBY_SORTBY_LIMIT_LIMIT_OFFSET_OFFSET