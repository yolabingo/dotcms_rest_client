from dotcms_rest_client.paths.v1_sites_site_id_ruleengine_conditions.post import ApiForpost


class V1SitesSiteIdRuleengineConditions(
    ApiForpost,
):
    pass
