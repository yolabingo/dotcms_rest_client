from dotcms_rest_client.paths.v1_caches_provider_provider_flush_group_id.delete import ApiFordelete


class V1CachesProviderProviderFlushGroupId(
    ApiFordelete,
):
    pass
