from dotcms_rest_client.paths.v1_logger.get import ApiForget
from dotcms_rest_client.paths.v1_logger.put import ApiForput


class V1Logger(
    ApiForget,
    ApiForput,
):
    pass
