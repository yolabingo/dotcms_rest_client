from dotcms_rest_client.paths.v1_portlet_portlet_id.get import ApiForget


class V1PortletPortletId(
    ApiForget,
):
    pass
