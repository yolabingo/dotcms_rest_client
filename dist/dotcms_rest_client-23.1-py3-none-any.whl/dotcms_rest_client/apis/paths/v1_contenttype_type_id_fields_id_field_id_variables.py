from dotcms_rest_client.paths.v1_contenttype_type_id_fields_id_field_id_variables.get import ApiForget
from dotcms_rest_client.paths.v1_contenttype_type_id_fields_id_field_id_variables.post import ApiForpost


class V1ContenttypeTypeIdFieldsIdFieldIdVariables(
    ApiForget,
    ApiForpost,
):
    pass
