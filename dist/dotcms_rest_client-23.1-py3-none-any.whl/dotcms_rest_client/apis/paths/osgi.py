from dotcms_rest_client.paths.osgi.post import ApiForpost


class Osgi(
    ApiForpost,
):
    pass
