from dotcms_rest_client.paths.v1_redis.put import ApiForput


class V1Redis(
    ApiForput,
):
    pass
