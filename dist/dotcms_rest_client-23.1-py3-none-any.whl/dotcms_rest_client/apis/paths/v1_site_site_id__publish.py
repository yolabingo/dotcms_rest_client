from dotcms_rest_client.paths.v1_site_site_id__publish.put import ApiForput


class V1SiteSiteIdPublish(
    ApiForput,
):
    pass
