from dotcms_rest_client.paths.v1_contenttype_type_id_fields_id_field_id.get import ApiForget
from dotcms_rest_client.paths.v1_contenttype_type_id_fields_id_field_id.put import ApiForput
from dotcms_rest_client.paths.v1_contenttype_type_id_fields_id_field_id.delete import ApiFordelete


class V1ContenttypeTypeIdFieldsIdFieldId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
