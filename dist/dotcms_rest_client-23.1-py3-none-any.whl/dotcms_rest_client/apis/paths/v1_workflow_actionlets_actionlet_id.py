from dotcms_rest_client.paths.v1_workflow_actionlets_actionlet_id.delete import ApiFordelete


class V1WorkflowActionletsActionletId(
    ApiFordelete,
):
    pass
