from dotcms_rest_client.paths.v1_portlet_portlet_id_portlet_id.delete import ApiFordelete


class V1PortletPortletIdPortletId(
    ApiFordelete,
):
    pass
