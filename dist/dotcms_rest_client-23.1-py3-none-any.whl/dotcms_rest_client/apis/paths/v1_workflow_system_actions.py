from dotcms_rest_client.paths.v1_workflow_system_actions.put import ApiForput


class V1WorkflowSystemActions(
    ApiForput,
):
    pass
