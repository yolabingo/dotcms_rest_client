from dotcms_rest_client.paths.role_loadbyname_params.get import ApiForget


class RoleLoadbynameParams(
    ApiForget,
):
    pass
