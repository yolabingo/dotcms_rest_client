from dotcms_rest_client.paths.bundle_sync.post import ApiForpost


class BundleSync(
    ApiForpost,
):
    pass
