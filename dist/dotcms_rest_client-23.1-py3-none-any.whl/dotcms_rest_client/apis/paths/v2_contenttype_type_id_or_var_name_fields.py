from dotcms_rest_client.paths.v2_contenttype_type_id_or_var_name_fields.get import ApiForget
from dotcms_rest_client.paths.v2_contenttype_type_id_or_var_name_fields.put import ApiForput
from dotcms_rest_client.paths.v2_contenttype_type_id_or_var_name_fields.post import ApiForpost
from dotcms_rest_client.paths.v2_contenttype_type_id_or_var_name_fields.delete import ApiFordelete


class V2ContenttypeTypeIdOrVarNameFields(
    ApiForget,
    ApiForput,
    ApiForpost,
    ApiFordelete,
):
    pass
