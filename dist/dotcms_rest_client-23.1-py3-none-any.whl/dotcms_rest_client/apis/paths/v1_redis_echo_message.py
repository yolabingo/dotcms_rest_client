from dotcms_rest_client.paths.v1_redis_echo_message.get import ApiForget


class V1RedisEchoMessage(
    ApiForget,
):
    pass
