from dotcms_rest_client.paths.v1_system_ruleengine_conditionlets.get import ApiForget


class V1SystemRuleengineConditionlets(
    ApiForget,
):
    pass
