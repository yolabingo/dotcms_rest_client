from dotcms_rest_client.paths.v1_workflow_schemes_actions_system_action.post import ApiForpost


class V1WorkflowSchemesActionsSystemAction(
    ApiForpost,
):
    pass
