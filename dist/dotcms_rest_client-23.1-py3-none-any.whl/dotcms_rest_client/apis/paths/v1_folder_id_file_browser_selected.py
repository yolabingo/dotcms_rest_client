from dotcms_rest_client.paths.v1_folder_id_file_browser_selected.put import ApiForput


class V1FolderIdFileBrowserSelected(
    ApiForput,
):
    pass
