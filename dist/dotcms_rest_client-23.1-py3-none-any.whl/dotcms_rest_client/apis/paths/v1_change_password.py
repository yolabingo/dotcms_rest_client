from dotcms_rest_client.paths.v1_change_password.post import ApiForpost


class V1ChangePassword(
    ApiForpost,
):
    pass
