from dotcms_rest_client.paths.v1_apps_import.post import ApiForpost


class V1AppsImport(
    ApiForpost,
):
    pass
