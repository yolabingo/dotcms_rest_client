from dotcms_rest_client.paths.ws_v1_system_events.get import ApiForget


class WsV1SystemEvents(
    ApiForget,
):
    pass
