from dotcms_rest_client.paths.v1_tags_tag_name_or_id_inode_inode.put import ApiForput


class V1TagsTagNameOrIdInodeInode(
    ApiForput,
):
    pass
