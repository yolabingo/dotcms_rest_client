from dotcms_rest_client.paths.v1_site_site_id_setup_progress.get import ApiForget


class V1SiteSiteIdSetupProgress(
    ApiForget,
):
    pass
