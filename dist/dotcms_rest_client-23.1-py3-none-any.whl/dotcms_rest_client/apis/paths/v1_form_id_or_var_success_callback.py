from dotcms_rest_client.paths.v1_form_id_or_var_success_callback.get import ApiForget


class V1FormIdOrVarSuccessCallback(
    ApiForget,
):
    pass
