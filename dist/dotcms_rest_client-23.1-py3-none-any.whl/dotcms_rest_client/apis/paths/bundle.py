from dotcms_rest_client.paths.bundle.post import ApiForpost


class Bundle(
    ApiForpost,
):
    pass
