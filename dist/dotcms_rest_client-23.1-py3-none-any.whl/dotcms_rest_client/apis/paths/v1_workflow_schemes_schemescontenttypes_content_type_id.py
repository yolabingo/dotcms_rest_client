from dotcms_rest_client.paths.v1_workflow_schemes_schemescontenttypes_content_type_id.get import ApiForget


class V1WorkflowSchemesSchemescontenttypesContentTypeId(
    ApiForget,
):
    pass
