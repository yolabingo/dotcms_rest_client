from dotcms_rest_client.paths.bundle_updatebundle_params.get import ApiForget


class BundleUpdatebundleParams(
    ApiForget,
):
    pass
