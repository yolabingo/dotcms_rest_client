from dotcms_rest_client.paths.v1_esindex_indexlist_params.get import ApiForget


class V1EsindexIndexlistParams(
    ApiForget,
):
    pass
