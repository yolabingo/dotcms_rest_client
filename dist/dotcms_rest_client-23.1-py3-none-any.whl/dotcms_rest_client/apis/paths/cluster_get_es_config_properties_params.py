from dotcms_rest_client.paths.cluster_get_es_config_properties_params.get import ApiForget


class ClusterGetESConfigPropertiesParams(
    ApiForget,
):
    pass
