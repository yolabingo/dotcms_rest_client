from dotcms_rest_client.paths.v1_folder_by_path.post import ApiForpost


class V1FolderByPath(
    ApiForpost,
):
    pass
