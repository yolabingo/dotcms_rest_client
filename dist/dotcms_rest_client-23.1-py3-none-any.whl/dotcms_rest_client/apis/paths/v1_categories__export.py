from dotcms_rest_client.paths.v1_categories__export.get import ApiForget


class V1CategoriesExport(
    ApiForget,
):
    pass
