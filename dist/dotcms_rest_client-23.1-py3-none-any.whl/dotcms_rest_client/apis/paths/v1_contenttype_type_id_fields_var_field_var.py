from dotcms_rest_client.paths.v1_contenttype_type_id_fields_var_field_var.get import ApiForget
from dotcms_rest_client.paths.v1_contenttype_type_id_fields_var_field_var.put import ApiForput
from dotcms_rest_client.paths.v1_contenttype_type_id_fields_var_field_var.delete import ApiFordelete


class V1ContenttypeTypeIdFieldsVarFieldVar(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
