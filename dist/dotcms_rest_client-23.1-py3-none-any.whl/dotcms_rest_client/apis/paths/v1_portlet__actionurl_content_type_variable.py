from dotcms_rest_client.paths.v1_portlet__actionurl_content_type_variable.get import ApiForget


class V1PortletActionurlContentTypeVariable(
    ApiForget,
):
    pass
