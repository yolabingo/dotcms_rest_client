from dotcms_rest_client.paths.config_regenerate_key.post import ApiForpost


class ConfigRegenerateKey(
    ApiForpost,
):
    pass
