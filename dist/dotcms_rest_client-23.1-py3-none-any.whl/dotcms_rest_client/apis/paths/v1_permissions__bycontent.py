from dotcms_rest_client.paths.v1_permissions__bycontent.get import ApiForget


class V1PermissionsBycontent(
    ApiForget,
):
    pass
