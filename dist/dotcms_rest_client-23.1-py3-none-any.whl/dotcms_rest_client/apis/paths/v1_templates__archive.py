from dotcms_rest_client.paths.v1_templates__archive.put import ApiForput


class V1TemplatesArchive(
    ApiForput,
):
    pass
