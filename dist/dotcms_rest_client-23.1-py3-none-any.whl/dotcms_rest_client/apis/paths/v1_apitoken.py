from dotcms_rest_client.paths.v1_apitoken.post import ApiForpost


class V1Apitoken(
    ApiForpost,
):
    pass
