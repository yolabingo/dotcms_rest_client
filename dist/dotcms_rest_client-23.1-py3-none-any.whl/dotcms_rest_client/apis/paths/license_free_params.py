from dotcms_rest_client.paths.license_free_params.post import ApiForpost


class LicenseFreeParams(
    ApiForpost,
):
    pass
