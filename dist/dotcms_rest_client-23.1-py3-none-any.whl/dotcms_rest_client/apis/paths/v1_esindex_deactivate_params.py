from dotcms_rest_client.paths.v1_esindex_deactivate_params.put import ApiForput


class V1EsindexDeactivateParams(
    ApiForput,
):
    pass
