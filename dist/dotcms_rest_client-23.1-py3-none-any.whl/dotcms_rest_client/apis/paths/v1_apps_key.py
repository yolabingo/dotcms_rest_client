from dotcms_rest_client.paths.v1_apps_key.get import ApiForget
from dotcms_rest_client.paths.v1_apps_key.delete import ApiFordelete


class V1AppsKey(
    ApiForget,
    ApiFordelete,
):
    pass
