from dotcms_rest_client.paths.v1_site_variable.put import ApiForput


class V1SiteVariable(
    ApiForput,
):
    pass
