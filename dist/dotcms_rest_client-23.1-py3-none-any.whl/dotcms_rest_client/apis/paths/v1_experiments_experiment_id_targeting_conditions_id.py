from dotcms_rest_client.paths.v1_experiments_experiment_id_targeting_conditions_id.delete import ApiFordelete


class V1ExperimentsExperimentIdTargetingConditionsId(
    ApiFordelete,
):
    pass
