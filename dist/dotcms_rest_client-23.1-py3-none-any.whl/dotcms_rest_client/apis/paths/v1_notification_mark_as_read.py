from dotcms_rest_client.paths.v1_notification_mark_as_read.put import ApiForput


class V1NotificationMarkAsRead(
    ApiForput,
):
    pass
