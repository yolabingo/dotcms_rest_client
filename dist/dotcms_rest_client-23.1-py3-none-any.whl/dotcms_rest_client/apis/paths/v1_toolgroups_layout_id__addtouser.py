from dotcms_rest_client.paths.v1_toolgroups_layout_id__addtouser.put import ApiForput


class V1ToolgroupsLayoutIdAddtouser(
    ApiForput,
):
    pass
