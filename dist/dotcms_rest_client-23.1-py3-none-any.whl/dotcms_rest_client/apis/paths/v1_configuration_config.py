from dotcms_rest_client.paths.v1_configuration_config.get import ApiForget


class V1ConfigurationConfig(
    ApiForget,
):
    pass
