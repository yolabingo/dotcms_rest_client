from dotcms_rest_client.paths.v1_versionables_versionable_inode__bringback.put import ApiForput


class V1VersionablesVersionableInodeBringback(
    ApiForput,
):
    pass
