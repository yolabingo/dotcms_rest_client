from dotcms_rest_client.paths.v1_workflow_schemes.get import ApiForget
from dotcms_rest_client.paths.v1_workflow_schemes.post import ApiForpost


class V1WorkflowSchemes(
    ApiForget,
    ApiForpost,
):
    pass
