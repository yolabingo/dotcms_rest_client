from dotcms_rest_client.paths.config_save_company_logo.post import ApiForpost


class ConfigSaveCompanyLogo(
    ApiForpost,
):
    pass
