from dotcms_rest_client.paths.v1_workflow_contenttypes_content_type_var_or_id_system_actions.get import ApiForget


class V1WorkflowContenttypesContentTypeVarOrIdSystemActions(
    ApiForget,
):
    pass
