from dotcms_rest_client.paths.v1_workflow_contentlet_inode_actions.get import ApiForget


class V1WorkflowContentletInodeActions(
    ApiForget,
):
    pass
