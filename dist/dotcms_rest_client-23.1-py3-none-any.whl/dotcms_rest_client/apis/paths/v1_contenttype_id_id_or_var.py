from dotcms_rest_client.paths.v1_contenttype_id_id_or_var.get import ApiForget
from dotcms_rest_client.paths.v1_contenttype_id_id_or_var.put import ApiForput
from dotcms_rest_client.paths.v1_contenttype_id_id_or_var.delete import ApiFordelete


class V1ContenttypeIdIdOrVar(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
