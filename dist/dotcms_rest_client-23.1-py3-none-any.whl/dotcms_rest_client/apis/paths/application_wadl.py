from dotcms_rest_client.paths.application_wadl.get import ApiForget


class ApplicationWadl(
    ApiForget,
):
    pass
