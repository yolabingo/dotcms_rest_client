from dotcms_rest_client.paths.v1_sites_site_id_ruleengine_actions.post import ApiForpost


class V1SitesSiteIdRuleengineActions(
    ApiForpost,
):
    pass
