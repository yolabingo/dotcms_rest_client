from dotcms_rest_client.paths.util_encode_query_param_value_params.get import ApiForget


class UtilEncodeQueryParamValueParams(
    ApiForget,
):
    pass
