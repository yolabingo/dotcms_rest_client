from dotcms_rest_client.paths.v1_containers__bulkarchive.put import ApiForput


class V1ContainersBulkarchive(
    ApiForput,
):
    pass
