from dotcms_rest_client.paths.v1_system_status_alive.get import ApiForget


class V1SystemStatusAlive(
    ApiForget,
):
    pass
