from dotcms_rest_client.paths.v1_workflow_actions_default_firemultipart_system_action.put import ApiForput


class V1WorkflowActionsDefaultFiremultipartSystemAction(
    ApiForput,
):
    pass
