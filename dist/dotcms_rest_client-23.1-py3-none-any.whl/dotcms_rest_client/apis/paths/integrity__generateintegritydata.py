from dotcms_rest_client.paths.integrity__generateintegritydata.post import ApiForpost


class IntegrityGenerateintegritydata(
    ApiForpost,
):
    pass
