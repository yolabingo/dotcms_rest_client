from dotcms_rest_client.paths.v1_folder_createfolders_site_name.post import ApiForpost


class V1FolderCreatefoldersSiteName(
    ApiForpost,
):
    pass
