from dotcms_rest_client.paths.config_save_company_auth_type_info.post import ApiForpost


class ConfigSaveCompanyAuthTypeInfo(
    ApiForpost,
):
    pass
