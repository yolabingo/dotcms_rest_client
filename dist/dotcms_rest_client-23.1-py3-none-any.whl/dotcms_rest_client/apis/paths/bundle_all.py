from dotcms_rest_client.paths.bundle_all.delete import ApiFordelete


class BundleAll(
    ApiFordelete,
):
    pass
