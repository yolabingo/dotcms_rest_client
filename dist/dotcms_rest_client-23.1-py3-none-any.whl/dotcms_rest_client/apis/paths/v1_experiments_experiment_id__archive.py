from dotcms_rest_client.paths.v1_experiments_experiment_id__archive.put import ApiForput


class V1ExperimentsExperimentIdArchive(
    ApiForput,
):
    pass
