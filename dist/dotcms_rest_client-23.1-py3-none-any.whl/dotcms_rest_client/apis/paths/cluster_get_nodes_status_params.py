from dotcms_rest_client.paths.cluster_get_nodes_status_params.get import ApiForget


class ClusterGetNodesStatusParams(
    ApiForget,
):
    pass
