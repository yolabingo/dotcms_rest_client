from dotcms_rest_client.paths.v1_appconfiguration.get import ApiForget


class V1Appconfiguration(
    ApiForget,
):
    pass
