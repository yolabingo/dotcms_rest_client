from dotcms_rest_client.paths.v1_users_current.get import ApiForget
from dotcms_rest_client.paths.v1_users_current.put import ApiForput


class V1UsersCurrent(
    ApiForget,
    ApiForput,
):
    pass
