from dotcms_rest_client.paths.v1_forgotpassword.post import ApiForpost


class V1Forgotpassword(
    ApiForpost,
):
    pass
