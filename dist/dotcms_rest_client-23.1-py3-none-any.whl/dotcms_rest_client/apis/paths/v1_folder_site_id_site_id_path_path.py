from dotcms_rest_client.paths.v1_folder_site_id_site_id_path_path.get import ApiForget


class V1FolderSiteIdSiteIdPathPath(
    ApiForget,
):
    pass
