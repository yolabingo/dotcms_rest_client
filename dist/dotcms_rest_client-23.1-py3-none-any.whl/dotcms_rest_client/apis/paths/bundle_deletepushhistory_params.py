from dotcms_rest_client.paths.bundle_deletepushhistory_params.get import ApiForget


class BundleDeletepushhistoryParams(
    ApiForget,
):
    pass
