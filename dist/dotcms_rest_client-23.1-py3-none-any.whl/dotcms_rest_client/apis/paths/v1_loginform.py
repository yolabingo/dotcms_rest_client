from dotcms_rest_client.paths.v1_loginform.post import ApiForpost


class V1Loginform(
    ApiForpost,
):
    pass
