from dotcms_rest_client.paths.license_all_params.get import ApiForget


class LicenseAllParams(
    ApiForget,
):
    pass
