from dotcms_rest_client.paths.v1_workflow_reorder_step_step_id_order_order.put import ApiForput


class V1WorkflowReorderStepStepIdOrderOrder(
    ApiForput,
):
    pass
