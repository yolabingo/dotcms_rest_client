from dotcms_rest_client.paths.v1_workflow_actions_action_id_actionlets.get import ApiForget
from dotcms_rest_client.paths.v1_workflow_actions_action_id_actionlets.post import ApiForpost


class V1WorkflowActionsActionIdActionlets(
    ApiForget,
    ApiForpost,
):
    pass
