from dotcms_rest_client.paths.license_request_code_params.post import ApiForpost


class LicenseRequestCodeParams(
    ApiForpost,
):
    pass
