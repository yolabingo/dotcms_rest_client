from dotcms_rest_client.paths.v1_experiments_is_user_included.post import ApiForpost


class V1ExperimentsIsUserIncluded(
    ApiForpost,
):
    pass
