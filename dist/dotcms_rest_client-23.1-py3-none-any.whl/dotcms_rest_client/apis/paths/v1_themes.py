from dotcms_rest_client.paths.v1_themes.get import ApiForget


class V1Themes(
    ApiForget,
):
    pass
