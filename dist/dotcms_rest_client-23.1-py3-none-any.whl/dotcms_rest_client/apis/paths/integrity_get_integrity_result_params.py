from dotcms_rest_client.paths.integrity_get_integrity_result_params.get import ApiForget


class IntegrityGetIntegrityResultParams(
    ApiForget,
):
    pass
