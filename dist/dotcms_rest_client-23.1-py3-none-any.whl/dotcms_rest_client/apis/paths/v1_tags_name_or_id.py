from dotcms_rest_client.paths.v1_tags_name_or_id.get import ApiForget


class V1TagsNameOrId(
    ApiForget,
):
    pass
