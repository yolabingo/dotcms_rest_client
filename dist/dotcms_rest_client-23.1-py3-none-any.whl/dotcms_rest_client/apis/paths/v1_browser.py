from dotcms_rest_client.paths.v1_browser.post import ApiForpost


class V1Browser(
    ApiForpost,
):
    pass
