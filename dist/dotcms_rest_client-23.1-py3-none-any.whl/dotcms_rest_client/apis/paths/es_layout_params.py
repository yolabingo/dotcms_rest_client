from dotcms_rest_client.paths.es_layout_params.get import ApiForget


class EsLayoutParams(
    ApiForget,
):
    pass
