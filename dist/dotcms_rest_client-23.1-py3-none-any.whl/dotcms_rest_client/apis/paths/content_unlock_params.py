from dotcms_rest_client.paths.content_unlock_params.put import ApiForput


class ContentUnlockParams(
    ApiForput,
):
    pass
