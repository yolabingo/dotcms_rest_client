from dotcms_rest_client.paths.v3_contenttype_type_id_or_var_name_fields_id.put import ApiForput


class V3ContenttypeTypeIdOrVarNameFieldsId(
    ApiForput,
):
    pass
