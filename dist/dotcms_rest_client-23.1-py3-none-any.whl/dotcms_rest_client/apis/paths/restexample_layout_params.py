from dotcms_rest_client.paths.restexample_layout_params.get import ApiForget


class RestexampleLayoutParams(
    ApiForget,
):
    pass
