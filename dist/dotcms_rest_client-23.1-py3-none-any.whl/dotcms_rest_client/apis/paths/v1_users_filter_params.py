from dotcms_rest_client.paths.v1_users_filter_params.get import ApiForget


class V1UsersFilterParams(
    ApiForget,
):
    pass
