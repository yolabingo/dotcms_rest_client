from dotcms_rest_client.paths.v1_contenttype_base_variable_name__copy.post import ApiForpost


class V1ContenttypeBaseVariableNameCopy(
    ApiForpost,
):
    pass
