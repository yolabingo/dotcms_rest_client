from dotcms_rest_client.paths.v1_workflow_contentlet_actions_bulk.post import ApiForpost


class V1WorkflowContentletActionsBulk(
    ApiForpost,
):
    pass
