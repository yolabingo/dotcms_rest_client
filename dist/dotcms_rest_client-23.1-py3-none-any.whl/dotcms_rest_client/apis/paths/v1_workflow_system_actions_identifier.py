from dotcms_rest_client.paths.v1_workflow_system_actions_identifier.delete import ApiFordelete


class V1WorkflowSystemActionsIdentifier(
    ApiFordelete,
):
    pass
