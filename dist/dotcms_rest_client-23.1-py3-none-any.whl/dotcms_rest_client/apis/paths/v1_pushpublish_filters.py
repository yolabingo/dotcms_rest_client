from dotcms_rest_client.paths.v1_pushpublish_filters.get import ApiForget
from dotcms_rest_client.paths.v1_pushpublish_filters.put import ApiForput
from dotcms_rest_client.paths.v1_pushpublish_filters.post import ApiForpost


class V1PushpublishFilters(
    ApiForget,
    ApiForput,
    ApiForpost,
):
    pass
