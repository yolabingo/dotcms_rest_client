from dotcms_rest_client.paths.v1_apps_export.post import ApiForpost


class V1AppsExport(
    ApiForpost,
):
    pass
