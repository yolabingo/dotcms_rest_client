from dotcms_rest_client.paths.v1_contenttype_type_id_fields_var_field_var_variables.get import ApiForget
from dotcms_rest_client.paths.v1_contenttype_type_id_fields_var_field_var_variables.post import ApiForpost


class V1ContenttypeTypeIdFieldsVarFieldVarVariables(
    ApiForget,
    ApiForpost,
):
    pass
