from dotcms_rest_client.paths.v2_languages_language_id.put import ApiForput
from dotcms_rest_client.paths.v2_languages_language_id.delete import ApiFordelete


class V2LanguagesLanguageId(
    ApiForput,
    ApiFordelete,
):
    pass
