from dotcms_rest_client.paths.v1_page_render_html_uri.get import ApiForget


class V1PageRenderHTMLUri(
    ApiForget,
):
    pass
