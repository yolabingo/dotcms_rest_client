from dotcms_rest_client.paths.bundle_deleteenvironmentpushhistory_params.get import ApiForget


class BundleDeleteenvironmentpushhistoryParams(
    ApiForget,
):
    pass
