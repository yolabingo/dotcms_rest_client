from dotcms_rest_client.paths.audit_publishing_get_bundle_id.get import ApiForget


class AuditPublishingGetBundleId(
    ApiForget,
):
    pass
