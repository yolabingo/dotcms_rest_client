from dotcms_rest_client.paths.v1_site_current_site.get import ApiForget


class V1SiteCurrentSite(
    ApiForget,
):
    pass
