from dotcms_rest_client.paths.v1_content__canlock_inode_or_identifier.get import ApiForget


class V1ContentCanlockInodeOrIdentifier(
    ApiForget,
):
    pass
