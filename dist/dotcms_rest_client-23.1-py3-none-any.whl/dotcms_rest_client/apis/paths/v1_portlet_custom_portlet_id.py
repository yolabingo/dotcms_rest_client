from dotcms_rest_client.paths.v1_portlet_custom_portlet_id.delete import ApiFordelete


class V1PortletCustomPortletId(
    ApiFordelete,
):
    pass
