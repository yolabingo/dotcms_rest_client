from dotcms_rest_client.paths.v2_languages_language_tag.get import ApiForget
from dotcms_rest_client.paths.v2_languages_language_tag.post import ApiForpost


class V2LanguagesLanguageTag(
    ApiForget,
    ApiForpost,
):
    pass
