from dotcms_rest_client.paths.v1_page_page_id__deepcopy.put import ApiForput


class V1PagePageIdDeepcopy(
    ApiForput,
):
    pass
