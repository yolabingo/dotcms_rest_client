from dotcms_rest_client.paths.bundle_olderthan_older_than.delete import ApiFordelete


class BundleOlderthanOlderThan(
    ApiFordelete,
):
    pass
