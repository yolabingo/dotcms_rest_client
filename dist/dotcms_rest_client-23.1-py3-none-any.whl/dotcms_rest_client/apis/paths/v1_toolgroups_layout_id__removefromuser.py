from dotcms_rest_client.paths.v1_toolgroups_layout_id__removefromuser.put import ApiForput


class V1ToolgroupsLayoutIdRemovefromuser(
    ApiForput,
):
    pass
