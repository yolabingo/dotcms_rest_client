from dotcms_rest_client.paths.v1_caches_provider_provider_flush.delete import ApiFordelete


class V1CachesProviderProviderFlush(
    ApiFordelete,
):
    pass
