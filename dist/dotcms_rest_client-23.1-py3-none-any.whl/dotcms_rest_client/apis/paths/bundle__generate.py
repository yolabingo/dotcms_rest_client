from dotcms_rest_client.paths.bundle__generate.post import ApiForpost


class BundleGenerate(
    ApiForpost,
):
    pass
