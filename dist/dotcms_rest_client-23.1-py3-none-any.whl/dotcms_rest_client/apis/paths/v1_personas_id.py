from dotcms_rest_client.paths.v1_personas_id.get import ApiForget


class V1PersonasId(
    ApiForget,
):
    pass
