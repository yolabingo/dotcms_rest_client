from dotcms_rest_client.paths.v1_dotsaml_metadata_idp_config_id.get import ApiForget


class V1DotsamlMetadataIdpConfigId(
    ApiForget,
):
    pass
