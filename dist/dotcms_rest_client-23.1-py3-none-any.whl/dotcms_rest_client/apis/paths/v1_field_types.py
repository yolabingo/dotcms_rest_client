from dotcms_rest_client.paths.v1_field_types.get import ApiForget


class V1FieldTypes(
    ApiForget,
):
    pass
