from dotcms_rest_client.paths.cluster_remove_params.post import ApiForpost


class ClusterRemoveParams(
    ApiForpost,
):
    pass
