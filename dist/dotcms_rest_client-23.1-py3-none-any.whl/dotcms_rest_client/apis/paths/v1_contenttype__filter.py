from dotcms_rest_client.paths.v1_contenttype__filter.post import ApiForpost


class V1ContenttypeFilter(
    ApiForpost,
):
    pass
