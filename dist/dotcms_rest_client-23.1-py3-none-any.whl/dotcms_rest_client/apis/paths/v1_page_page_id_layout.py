from dotcms_rest_client.paths.v1_page_page_id_layout.post import ApiForpost


class V1PagePageIdLayout(
    ApiForpost,
):
    pass
