from dotcms_rest_client.paths.v1_tags_tag_id.delete import ApiFordelete


class V1TagsTagId(
    ApiFordelete,
):
    pass
