from dotcms_rest_client.paths.v1_maintenance__download_assets.get import ApiForget


class V1MaintenanceDownloadAssets(
    ApiForget,
):
    pass
