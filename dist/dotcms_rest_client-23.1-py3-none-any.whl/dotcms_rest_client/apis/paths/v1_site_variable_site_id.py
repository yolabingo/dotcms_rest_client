from dotcms_rest_client.paths.v1_site_variable_site_id.get import ApiForget


class V1SiteVariableSiteId(
    ApiForget,
):
    pass
