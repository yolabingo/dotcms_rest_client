from dotcms_rest_client.paths.content_lock_params.put import ApiForput


class ContentLockParams(
    ApiForput,
):
    pass
