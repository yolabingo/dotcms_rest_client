from dotcms_rest_client.paths.v1_containers_id__copy.post import ApiForpost


class V1ContainersIdCopy(
    ApiForpost,
):
    pass
