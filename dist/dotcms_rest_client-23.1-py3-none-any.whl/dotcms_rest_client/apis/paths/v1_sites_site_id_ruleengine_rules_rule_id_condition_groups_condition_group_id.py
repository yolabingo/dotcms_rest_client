from dotcms_rest_client.paths.v1_sites_site_id_ruleengine_rules_rule_id_condition_groups_condition_group_id.delete import ApiFordelete


class V1SitesSiteIdRuleengineRulesRuleIdConditionGroupsConditionGroupId(
    ApiFordelete,
):
    pass
