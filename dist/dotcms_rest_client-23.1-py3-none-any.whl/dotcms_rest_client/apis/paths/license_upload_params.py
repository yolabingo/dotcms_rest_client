from dotcms_rest_client.paths.license_upload_params.post import ApiForpost


class LicenseUploadParams(
    ApiForpost,
):
    pass
