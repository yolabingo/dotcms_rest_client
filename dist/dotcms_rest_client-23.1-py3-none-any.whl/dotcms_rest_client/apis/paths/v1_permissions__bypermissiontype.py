from dotcms_rest_client.paths.v1_permissions__bypermissiontype.get import ApiForget


class V1PermissionsBypermissiontype(
    ApiForget,
):
    pass
