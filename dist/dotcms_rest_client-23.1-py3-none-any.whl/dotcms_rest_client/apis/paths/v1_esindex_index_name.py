from dotcms_rest_client.paths.v1_esindex_index_name.put import ApiForput
from dotcms_rest_client.paths.v1_esindex_index_name.delete import ApiFordelete


class V1EsindexIndexName(
    ApiForput,
    ApiFordelete,
):
    pass
