from dotcms_rest_client.paths.v1_portlet_portlet_id__doesuserhaveaccess.get import ApiForget


class V1PortletPortletIdDoesuserhaveaccess(
    ApiForget,
):
    pass
