from dotcms_rest_client.paths.user_getloggedinuser_params.get import ApiForget


class UserGetloggedinuserParams(
    ApiForget,
):
    pass
