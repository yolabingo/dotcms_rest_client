from dotcms_rest_client.paths.v1_sites_site_id_ruleengine_rules_rule_id.get import ApiForget
from dotcms_rest_client.paths.v1_sites_site_id_ruleengine_rules_rule_id.put import ApiForput
from dotcms_rest_client.paths.v1_sites_site_id_ruleengine_rules_rule_id.delete import ApiFordelete


class V1SitesSiteIdRuleengineRulesRuleId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
