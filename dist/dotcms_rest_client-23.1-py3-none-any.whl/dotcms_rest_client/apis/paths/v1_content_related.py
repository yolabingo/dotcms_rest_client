from dotcms_rest_client.paths.v1_content_related.post import ApiForpost


class V1ContentRelated(
    ApiForpost,
):
    pass
