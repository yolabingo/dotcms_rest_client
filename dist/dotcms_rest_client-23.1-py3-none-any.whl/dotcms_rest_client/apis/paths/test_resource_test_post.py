from dotcms_rest_client.paths.test_resource_test_post.post import ApiForpost


class TestResourceTestPost(
    ApiForpost,
):
    pass
