from dotcms_rest_client.paths.v2_languages_i18n.post import ApiForpost


class V2LanguagesI18n(
    ApiForpost,
):
    pass
