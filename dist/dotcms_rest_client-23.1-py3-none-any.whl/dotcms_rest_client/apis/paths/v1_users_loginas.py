from dotcms_rest_client.paths.v1_users_loginas.post import ApiForpost


class V1UsersLoginas(
    ApiForpost,
):
    pass
