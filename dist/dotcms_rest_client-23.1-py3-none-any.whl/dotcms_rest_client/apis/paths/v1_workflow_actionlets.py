from dotcms_rest_client.paths.v1_workflow_actionlets.get import ApiForget


class V1WorkflowActionlets(
    ApiForget,
):
    pass
