from dotcms_rest_client.paths.v1_containers_delete_container_id_content_contentlet_id_uid_uid.delete import ApiFordelete


class V1ContainersDeleteContainerIdContentContentletIdUidUid(
    ApiFordelete,
):
    pass
