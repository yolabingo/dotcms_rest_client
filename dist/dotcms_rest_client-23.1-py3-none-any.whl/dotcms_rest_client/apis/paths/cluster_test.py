from dotcms_rest_client.paths.cluster_test.get import ApiForget


class ClusterTest(
    ApiForget,
):
    pass
