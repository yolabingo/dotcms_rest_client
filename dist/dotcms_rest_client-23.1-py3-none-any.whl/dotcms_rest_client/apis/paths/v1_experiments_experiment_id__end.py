from dotcms_rest_client.paths.v1_experiments_experiment_id__end.post import ApiForpost


class V1ExperimentsExperimentIdEnd(
    ApiForpost,
):
    pass
