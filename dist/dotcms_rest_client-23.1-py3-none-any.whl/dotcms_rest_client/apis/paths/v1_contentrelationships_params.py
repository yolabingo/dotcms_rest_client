from dotcms_rest_client.paths.v1_contentrelationships_params.get import ApiForget


class V1ContentrelationshipsParams(
    ApiForget,
):
    pass
