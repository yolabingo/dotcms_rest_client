from dotcms_rest_client.paths.content_indexcount_query.get import ApiForget


class ContentIndexcountQuery(
    ApiForget,
):
    pass
