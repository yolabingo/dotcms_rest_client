from dotcms_rest_client.paths.v1_workflow_schemes_scheme_id_system_actions.get import ApiForget


class V1WorkflowSchemesSchemeIdSystemActions(
    ApiForget,
):
    pass
