from dotcms_rest_client.paths.v1_folder_site_name.delete import ApiFordelete


class V1FolderSiteName(
    ApiFordelete,
):
    pass
