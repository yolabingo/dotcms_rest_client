from dotcms_rest_client.paths.personas_sites_id.get import ApiForget


class PersonasSitesId(
    ApiForget,
):
    pass
