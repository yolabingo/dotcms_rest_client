from dotcms_rest_client.paths.v1_esindex_clear_params.put import ApiForput


class V1EsindexClearParams(
    ApiForput,
):
    pass
