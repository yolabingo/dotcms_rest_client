from dotcms_rest_client.paths.v1_roles_checkuserroles_userid_user_id_roleids_role_ids.get import ApiForget


class V1RolesCheckuserrolesUseridUserIdRoleidsRoleIds(
    ApiForget,
):
    pass
