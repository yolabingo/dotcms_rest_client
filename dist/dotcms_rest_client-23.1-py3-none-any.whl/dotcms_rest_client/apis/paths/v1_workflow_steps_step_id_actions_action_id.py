from dotcms_rest_client.paths.v1_workflow_steps_step_id_actions_action_id.get import ApiForget
from dotcms_rest_client.paths.v1_workflow_steps_step_id_actions_action_id.delete import ApiFordelete


class V1WorkflowStepsStepIdActionsActionId(
    ApiForget,
    ApiFordelete,
):
    pass
