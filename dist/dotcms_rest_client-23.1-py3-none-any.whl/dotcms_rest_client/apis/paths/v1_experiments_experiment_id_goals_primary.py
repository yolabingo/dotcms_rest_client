from dotcms_rest_client.paths.v1_experiments_experiment_id_goals_primary.delete import ApiFordelete


class V1ExperimentsExperimentIdGoalsPrimary(
    ApiFordelete,
):
    pass
