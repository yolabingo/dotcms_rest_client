from dotcms_rest_client.paths.v1_templates__publish.put import ApiForput


class V1TemplatesPublish(
    ApiForput,
):
    pass
