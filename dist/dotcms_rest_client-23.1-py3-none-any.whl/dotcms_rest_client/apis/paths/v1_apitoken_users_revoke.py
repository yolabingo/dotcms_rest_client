from dotcms_rest_client.paths.v1_apitoken_users_revoke.put import ApiForput


class V1ApitokenUsersRevoke(
    ApiForput,
):
    pass
