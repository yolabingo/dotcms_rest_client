from dotcms_rest_client.paths.bundle__download_bundle_id.get import ApiForget


class BundleDownloadBundleId(
    ApiForget,
):
    pass
