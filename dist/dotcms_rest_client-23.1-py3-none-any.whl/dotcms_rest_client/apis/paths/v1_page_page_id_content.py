from dotcms_rest_client.paths.v1_page_page_id_content.post import ApiForpost


class V1PagePageIdContent(
    ApiForpost,
):
    pass
