from dotcms_rest_client.paths.bundle_ids.delete import ApiFordelete


class BundleIds(
    ApiFordelete,
):
    pass
