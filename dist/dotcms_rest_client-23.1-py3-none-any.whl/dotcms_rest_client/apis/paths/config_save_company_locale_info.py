from dotcms_rest_client.paths.config_save_company_locale_info.post import ApiForpost


class ConfigSaveCompanyLocaleInfo(
    ApiForpost,
):
    pass
