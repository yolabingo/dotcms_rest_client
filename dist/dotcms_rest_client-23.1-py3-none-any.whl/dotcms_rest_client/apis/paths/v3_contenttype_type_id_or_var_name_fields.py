from dotcms_rest_client.paths.v3_contenttype_type_id_or_var_name_fields.get import ApiForget
from dotcms_rest_client.paths.v3_contenttype_type_id_or_var_name_fields.delete import ApiFordelete


class V3ContenttypeTypeIdOrVarNameFields(
    ApiForget,
    ApiFordelete,
):
    pass
