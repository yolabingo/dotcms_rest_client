from dotcms_rest_client.paths.v1_templates_template_id__copy.put import ApiForput


class V1TemplatesTemplateIdCopy(
    ApiForput,
):
    pass
