from dotcms_rest_client.paths.v1_site_site_id__makedefault.put import ApiForput


class V1SiteSiteIdMakedefault(
    ApiForput,
):
    pass
