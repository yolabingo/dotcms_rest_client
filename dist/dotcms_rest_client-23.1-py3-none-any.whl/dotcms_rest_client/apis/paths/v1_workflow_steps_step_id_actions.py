from dotcms_rest_client.paths.v1_workflow_steps_step_id_actions.get import ApiForget
from dotcms_rest_client.paths.v1_workflow_steps_step_id_actions.post import ApiForpost


class V1WorkflowStepsStepIdActions(
    ApiForget,
    ApiForpost,
):
    pass
