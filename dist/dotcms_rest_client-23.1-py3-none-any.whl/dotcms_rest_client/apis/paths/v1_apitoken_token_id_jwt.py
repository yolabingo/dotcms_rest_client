from dotcms_rest_client.paths.v1_apitoken_token_id_jwt.get import ApiForget


class V1ApitokenTokenIdJwt(
    ApiForget,
):
    pass
