from dotcms_rest_client.paths.v1_languages_i18n.post import ApiForpost


class V1LanguagesI18n(
    ApiForpost,
):
    pass
