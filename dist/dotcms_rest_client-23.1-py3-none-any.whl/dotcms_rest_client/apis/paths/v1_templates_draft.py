from dotcms_rest_client.paths.v1_templates_draft.put import ApiForput


class V1TemplatesDraft(
    ApiForput,
):
    pass
