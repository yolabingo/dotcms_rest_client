from dotcms_rest_client.paths.rulesengine_layout_params.get import ApiForget


class RulesengineLayoutParams(
    ApiForget,
):
    pass
