from dotcms_rest_client.paths.v1_workflow_system_actions_workflow_action_id.get import ApiForget


class V1WorkflowSystemActionsWorkflowActionId(
    ApiForget,
):
    pass
