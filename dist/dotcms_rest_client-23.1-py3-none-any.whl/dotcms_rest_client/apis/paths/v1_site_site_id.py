from dotcms_rest_client.paths.v1_site_site_id.get import ApiForget
from dotcms_rest_client.paths.v1_site_site_id.delete import ApiFordelete


class V1SiteSiteId(
    ApiForget,
    ApiFordelete,
):
    pass
