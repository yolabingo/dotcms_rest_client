from dotcms_rest_client.paths.es_search.get import ApiForget
from dotcms_rest_client.paths.es_search.post import ApiForpost


class EsSearch(
    ApiForget,
    ApiForpost,
):
    pass
