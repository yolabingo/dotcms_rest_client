from dotcms_rest_client.paths.v1_experiments_experiment_id.delete import ApiFordelete
from dotcms_rest_client.paths.v1_experiments_experiment_id.patch import ApiForpatch


class V1ExperimentsExperimentId(
    ApiFordelete,
    ApiForpatch,
):
    pass
