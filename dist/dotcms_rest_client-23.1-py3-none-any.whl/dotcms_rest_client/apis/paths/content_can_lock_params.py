from dotcms_rest_client.paths.content_can_lock_params.put import ApiForput


class ContentCanLockParams(
    ApiForput,
):
    pass
