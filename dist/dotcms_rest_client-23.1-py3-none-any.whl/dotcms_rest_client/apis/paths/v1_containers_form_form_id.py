from dotcms_rest_client.paths.v1_containers_form_form_id.get import ApiForget


class V1ContainersFormFormId(
    ApiForget,
):
    pass
