from dotcms_rest_client.paths.v1_authentication_log_in_user.get import ApiForget


class V1AuthenticationLogInUser(
    ApiForget,
):
    pass
