from dotcms_rest_client.paths.v1_containers__unarchive.put import ApiForput


class V1ContainersUnarchive(
    ApiForput,
):
    pass
