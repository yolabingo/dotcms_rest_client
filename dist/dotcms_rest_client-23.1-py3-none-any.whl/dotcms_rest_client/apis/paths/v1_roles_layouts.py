from dotcms_rest_client.paths.v1_roles_layouts.post import ApiForpost
from dotcms_rest_client.paths.v1_roles_layouts.delete import ApiFordelete


class V1RolesLayouts(
    ApiForpost,
    ApiFordelete,
):
    pass
