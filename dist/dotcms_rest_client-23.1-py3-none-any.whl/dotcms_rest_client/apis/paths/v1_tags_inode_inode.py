from dotcms_rest_client.paths.v1_tags_inode_inode.get import ApiForget
from dotcms_rest_client.paths.v1_tags_inode_inode.delete import ApiFordelete


class V1TagsInodeInode(
    ApiForget,
    ApiFordelete,
):
    pass
