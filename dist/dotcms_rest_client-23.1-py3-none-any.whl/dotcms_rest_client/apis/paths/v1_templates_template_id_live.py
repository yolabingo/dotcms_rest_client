from dotcms_rest_client.paths.v1_templates_template_id_live.get import ApiForget


class V1TemplatesTemplateIdLive(
    ApiForget,
):
    pass
