from dotcms_rest_client.paths.v1_workflow_schemes_scheme_id_export.get import ApiForget


class V1WorkflowSchemesSchemeIdExport(
    ApiForget,
):
    pass
