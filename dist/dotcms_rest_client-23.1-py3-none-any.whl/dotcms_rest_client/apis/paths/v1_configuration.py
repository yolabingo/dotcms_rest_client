from dotcms_rest_client.paths.v1_configuration.get import ApiForget
from dotcms_rest_client.paths.v1_configuration.put import ApiForput


class V1Configuration(
    ApiForget,
    ApiForput,
):
    pass
