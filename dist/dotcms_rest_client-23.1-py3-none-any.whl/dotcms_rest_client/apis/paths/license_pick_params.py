from dotcms_rest_client.paths.license_pick_params.post import ApiForpost


class LicensePickParams(
    ApiForpost,
):
    pass
