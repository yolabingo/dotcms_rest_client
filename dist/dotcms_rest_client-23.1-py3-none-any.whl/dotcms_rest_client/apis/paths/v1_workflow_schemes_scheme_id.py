from dotcms_rest_client.paths.v1_workflow_schemes_scheme_id.put import ApiForput
from dotcms_rest_client.paths.v1_workflow_schemes_scheme_id.delete import ApiFordelete


class V1WorkflowSchemesSchemeId(
    ApiForput,
    ApiFordelete,
):
    pass
