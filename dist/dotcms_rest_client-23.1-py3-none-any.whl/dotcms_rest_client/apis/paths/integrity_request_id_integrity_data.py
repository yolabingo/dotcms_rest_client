from dotcms_rest_client.paths.integrity_request_id_integrity_data.get import ApiForget


class IntegrityRequestIdIntegrityData(
    ApiForget,
):
    pass
