from dotcms_rest_client.paths.v1_esindex_open_params.put import ApiForput


class V1EsindexOpenParams(
    ApiForput,
):
    pass
