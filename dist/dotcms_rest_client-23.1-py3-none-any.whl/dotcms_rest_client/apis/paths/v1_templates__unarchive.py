from dotcms_rest_client.paths.v1_templates__unarchive.put import ApiForput


class V1TemplatesUnarchive(
    ApiForput,
):
    pass
