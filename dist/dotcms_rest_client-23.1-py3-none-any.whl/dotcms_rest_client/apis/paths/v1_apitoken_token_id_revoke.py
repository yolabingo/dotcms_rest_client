from dotcms_rest_client.paths.v1_apitoken_token_id_revoke.put import ApiForput


class V1ApitokenTokenIdRevoke(
    ApiForput,
):
    pass
