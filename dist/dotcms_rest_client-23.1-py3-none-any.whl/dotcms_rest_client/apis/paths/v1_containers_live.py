from dotcms_rest_client.paths.v1_containers_live.get import ApiForget


class V1ContainersLive(
    ApiForget,
):
    pass
