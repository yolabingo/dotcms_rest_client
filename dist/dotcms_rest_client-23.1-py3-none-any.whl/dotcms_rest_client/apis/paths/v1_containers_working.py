from dotcms_rest_client.paths.v1_containers_working.get import ApiForget


class V1ContainersWorking(
    ApiForget,
):
    pass
