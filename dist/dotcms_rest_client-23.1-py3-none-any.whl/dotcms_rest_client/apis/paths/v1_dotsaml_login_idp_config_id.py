from dotcms_rest_client.paths.v1_dotsaml_login_idp_config_id.get import ApiForget
from dotcms_rest_client.paths.v1_dotsaml_login_idp_config_id.post import ApiForpost


class V1DotsamlLoginIdpConfigId(
    ApiForget,
    ApiForpost,
):
    pass
