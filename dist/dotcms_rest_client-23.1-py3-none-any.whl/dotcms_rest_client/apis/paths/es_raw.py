from dotcms_rest_client.paths.es_raw.get import ApiForget
from dotcms_rest_client.paths.es_raw.post import ApiForpost


class EsRaw(
    ApiForget,
    ApiForpost,
):
    pass
