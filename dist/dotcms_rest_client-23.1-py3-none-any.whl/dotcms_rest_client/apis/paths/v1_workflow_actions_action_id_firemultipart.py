from dotcms_rest_client.paths.v1_workflow_actions_action_id_firemultipart.put import ApiForput


class V1WorkflowActionsActionIdFiremultipart(
    ApiForput,
):
    pass
