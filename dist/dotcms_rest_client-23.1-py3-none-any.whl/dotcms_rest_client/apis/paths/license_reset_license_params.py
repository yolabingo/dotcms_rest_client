from dotcms_rest_client.paths.license_reset_license_params.post import ApiForpost


class LicenseResetLicenseParams(
    ApiForpost,
):
    pass
