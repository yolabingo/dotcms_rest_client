from dotcms_rest_client.paths.v1_system_ruleengine_actionlets.get import ApiForget


class V1SystemRuleengineActionlets(
    ApiForget,
):
    pass
