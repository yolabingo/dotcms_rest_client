from dotcms_rest_client.paths.v1_browsertree_sitename_sitename_uri.get import ApiForget


class V1BrowsertreeSitenameSitenameUri(
    ApiForget,
):
    pass
