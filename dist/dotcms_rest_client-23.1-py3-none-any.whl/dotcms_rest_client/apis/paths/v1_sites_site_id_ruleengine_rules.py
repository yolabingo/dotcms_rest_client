from dotcms_rest_client.paths.v1_sites_site_id_ruleengine_rules.get import ApiForget
from dotcms_rest_client.paths.v1_sites_site_id_ruleengine_rules.post import ApiForpost


class V1SitesSiteIdRuleengineRules(
    ApiForget,
    ApiForpost,
):
    pass
