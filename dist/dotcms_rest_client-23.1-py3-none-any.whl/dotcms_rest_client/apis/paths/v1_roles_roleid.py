from dotcms_rest_client.paths.v1_roles_roleid.get import ApiForget


class V1RolesRoleid(
    ApiForget,
):
    pass
