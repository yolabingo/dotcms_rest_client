from dotcms_rest_client.paths.v1_workflow_steps.post import ApiForpost


class V1WorkflowSteps(
    ApiForpost,
):
    pass
