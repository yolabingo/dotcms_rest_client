from dotcms_rest_client.paths.v2_contenttype_type_id_or_var_name_fields_id_field_id.get import ApiForget
from dotcms_rest_client.paths.v2_contenttype_type_id_or_var_name_fields_id_field_id.put import ApiForput
from dotcms_rest_client.paths.v2_contenttype_type_id_or_var_name_fields_id_field_id.delete import ApiFordelete


class V2ContenttypeTypeIdOrVarNameFieldsIdFieldId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
