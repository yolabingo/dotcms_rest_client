from dotcms_rest_client.paths.v1_page_copy_content.put import ApiForput


class V1PageCopyContent(
    ApiForput,
):
    pass
