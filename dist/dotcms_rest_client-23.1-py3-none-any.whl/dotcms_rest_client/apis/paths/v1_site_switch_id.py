from dotcms_rest_client.paths.v1_site_switch_id.put import ApiForput


class V1SiteSwitchId(
    ApiForput,
):
    pass
