from dotcms_rest_client.paths.v1_experiments.get import ApiForget
from dotcms_rest_client.paths.v1_experiments.post import ApiForpost


class V1Experiments(
    ApiForget,
    ApiForpost,
):
    pass
