from dotcms_rest_client.paths.v1_workflow_actions_action_id_fire.put import ApiForput


class V1WorkflowActionsActionIdFire(
    ApiForput,
):
    pass
