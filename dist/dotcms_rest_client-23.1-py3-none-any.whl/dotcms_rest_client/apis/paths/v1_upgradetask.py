from dotcms_rest_client.paths.v1_upgradetask.post import ApiForpost


class V1Upgradetask(
    ApiForpost,
):
    pass
