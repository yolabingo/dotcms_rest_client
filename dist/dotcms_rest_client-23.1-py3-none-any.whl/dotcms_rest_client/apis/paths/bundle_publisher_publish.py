from dotcms_rest_client.paths.bundle_publisher_publish.post import ApiForpost


class BundlePublisherPublish(
    ApiForpost,
):
    pass
