from dotcms_rest_client.paths.v1_authentication_api_token.post import ApiForpost


class V1AuthenticationApiToken(
    ApiForpost,
):
    pass
