from dotcms_rest_client.paths.portlet_params.get import ApiForget
from dotcms_rest_client.paths.portlet_params.post import ApiForpost


class PortletParams(
    ApiForget,
    ApiForpost,
):
    pass
