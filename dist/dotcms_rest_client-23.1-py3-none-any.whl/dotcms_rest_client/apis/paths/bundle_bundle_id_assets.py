from dotcms_rest_client.paths.bundle_bundle_id_assets.get import ApiForget


class BundleBundleIdAssets(
    ApiForget,
):
    pass
