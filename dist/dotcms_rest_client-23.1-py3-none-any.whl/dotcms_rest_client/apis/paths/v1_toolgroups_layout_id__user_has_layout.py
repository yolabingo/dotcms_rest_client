from dotcms_rest_client.paths.v1_toolgroups_layout_id__user_has_layout.get import ApiForget


class V1ToolgroupsLayoutIdUserHasLayout(
    ApiForget,
):
    pass
