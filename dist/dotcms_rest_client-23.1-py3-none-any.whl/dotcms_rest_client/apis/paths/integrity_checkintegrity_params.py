from dotcms_rest_client.paths.integrity_checkintegrity_params.get import ApiForget


class IntegrityCheckintegrityParams(
    ApiForget,
):
    pass
