from dotcms_rest_client.paths.v1_categories__import.post import ApiForpost


class V1CategoriesImport(
    ApiForpost,
):
    pass
