from dotcms_rest_client.paths.v1_site_site_id__archive.put import ApiForput


class V1SiteSiteIdArchive(
    ApiForput,
):
    pass
