from dotcms_rest_client.paths.bundle_all_success.delete import ApiFordelete


class BundleAllSuccess(
    ApiFordelete,
):
    pass
