from dotcms_rest_client.paths.restexample_test_params.get import ApiForget


class RestexampleTestParams(
    ApiForget,
):
    pass
