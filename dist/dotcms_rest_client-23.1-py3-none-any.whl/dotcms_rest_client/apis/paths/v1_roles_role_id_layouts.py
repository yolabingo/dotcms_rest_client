from dotcms_rest_client.paths.v1_roles_role_id_layouts.get import ApiForget


class V1RolesRoleIdLayouts(
    ApiForget,
):
    pass
