# do not import all endpoints into this module because that uses a lot of memory and stack frames
# if you need the ability to import all endpoints from this module, import them with
# from dotcms_rest_client.paths.util_encode_query_param_value_params import Api

from dotcms_rest_client.paths import PathValues

path = PathValues.UTIL_ENCODE_QUERY_PARAM_VALUE_PARAMS