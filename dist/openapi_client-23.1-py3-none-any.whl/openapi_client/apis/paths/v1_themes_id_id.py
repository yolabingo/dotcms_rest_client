from openapi_client.paths.v1_themes_id_id.get import ApiForget


class V1ThemesIdId(
    ApiForget,
):
    pass
