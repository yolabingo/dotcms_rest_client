from openapi_client.paths.v3_contenttype_type_id_or_var_name_fields_move.put import ApiForput


class V3ContenttypeTypeIdOrVarNameFieldsMove(
    ApiForput,
):
    pass
