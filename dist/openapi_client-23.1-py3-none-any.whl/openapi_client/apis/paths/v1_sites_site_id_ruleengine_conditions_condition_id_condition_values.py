from openapi_client.paths.v1_sites_site_id_ruleengine_conditions_condition_id_condition_values.get import ApiForget
from openapi_client.paths.v1_sites_site_id_ruleengine_conditions_condition_id_condition_values.post import ApiForpost


class V1SitesSiteIdRuleengineConditionsConditionIdConditionValues(
    ApiForget,
    ApiForpost,
):
    pass
