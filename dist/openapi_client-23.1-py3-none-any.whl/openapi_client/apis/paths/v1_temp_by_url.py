from openapi_client.paths.v1_temp_by_url.post import ApiForpost


class V1TempByUrl(
    ApiForpost,
):
    pass
