from openapi_client.paths.v1_page_search.get import ApiForget


class V1PageSearch(
    ApiForget,
):
    pass
