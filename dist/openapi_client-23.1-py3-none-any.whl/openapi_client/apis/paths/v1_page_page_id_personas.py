from openapi_client.paths.v1_page_page_id_personas.get import ApiForget


class V1PagePageIdPersonas(
    ApiForget,
):
    pass
