from openapi_client.paths.v1_logs_file_name__tail.get import ApiForget


class V1LogsFileNameTail(
    ApiForget,
):
    pass
