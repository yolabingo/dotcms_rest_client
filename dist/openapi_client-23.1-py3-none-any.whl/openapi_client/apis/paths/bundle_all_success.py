from openapi_client.paths.bundle_all_success.delete import ApiFordelete


class BundleAllSuccess(
    ApiFordelete,
):
    pass
