from openapi_client.paths.bundle_all_fail.delete import ApiFordelete


class BundleAllFail(
    ApiFordelete,
):
    pass
