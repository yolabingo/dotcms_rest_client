from openapi_client.paths.v1_workflow_defaultactions_contenttype_content_type_id.get import ApiForget


class V1WorkflowDefaultactionsContenttypeContentTypeId(
    ApiForget,
):
    pass
