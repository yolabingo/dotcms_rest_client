from openapi_client.paths.v1_workflow_actions.post import ApiForpost


class V1WorkflowActions(
    ApiForpost,
):
    pass
