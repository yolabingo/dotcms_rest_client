from openapi_client.paths.v1_esindex.get import ApiForget


class V1Esindex(
    ApiForget,
):
    pass
