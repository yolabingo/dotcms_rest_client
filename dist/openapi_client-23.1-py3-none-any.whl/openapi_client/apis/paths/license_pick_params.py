from openapi_client.paths.license_pick_params.post import ApiForpost


class LicensePickParams(
    ApiForpost,
):
    pass
