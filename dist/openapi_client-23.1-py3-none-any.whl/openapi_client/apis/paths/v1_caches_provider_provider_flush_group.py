from openapi_client.paths.v1_caches_provider_provider_flush_group.delete import ApiFordelete


class V1CachesProviderProviderFlushGroup(
    ApiFordelete,
):
    pass
