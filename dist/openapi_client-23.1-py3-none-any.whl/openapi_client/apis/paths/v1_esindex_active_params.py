from openapi_client.paths.v1_esindex_active_params.get import ApiForget


class V1EsindexActiveParams(
    ApiForget,
):
    pass
