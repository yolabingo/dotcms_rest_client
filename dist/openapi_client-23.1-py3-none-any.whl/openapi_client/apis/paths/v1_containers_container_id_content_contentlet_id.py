from openapi_client.paths.v1_containers_container_id_content_contentlet_id.get import ApiForget


class V1ContainersContainerIdContentContentletId(
    ApiForget,
):
    pass
