from openapi_client.paths.v1_users_login_as_data.get import ApiForget


class V1UsersLoginAsData(
    ApiForget,
):
    pass
