from openapi_client.paths.structure_path.get import ApiForget


class StructurePath(
    ApiForget,
):
    pass
