from openapi_client.paths.v1_system_i18n_lang_rsrc.get import ApiForget


class V1SystemI18nLangRsrc(
    ApiForget,
):
    pass
