from openapi_client.paths.integrity__fixconflictsfromremote.post import ApiForpost


class IntegrityFixconflictsfromremote(
    ApiForpost,
):
    pass
