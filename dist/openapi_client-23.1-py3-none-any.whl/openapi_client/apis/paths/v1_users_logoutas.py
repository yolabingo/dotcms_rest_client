from openapi_client.paths.v1_users_logoutas.put import ApiForput


class V1UsersLogoutas(
    ApiForput,
):
    pass
