from openapi_client.paths.v2_contenttype_type_id_or_var_name_fields_var_field_var.get import ApiForget
from openapi_client.paths.v2_contenttype_type_id_or_var_name_fields_var_field_var.put import ApiForput
from openapi_client.paths.v2_contenttype_type_id_or_var_name_fields_var_field_var.delete import ApiFordelete


class V2ContenttypeTypeIdOrVarNameFieldsVarFieldVar(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
