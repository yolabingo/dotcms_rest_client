from openapi_client.paths.personas_layout_params.get import ApiForget


class PersonasLayoutParams(
    ApiForget,
):
    pass
