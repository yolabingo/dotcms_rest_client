from openapi_client.paths.integrity_discardconflicts_params.get import ApiForget


class IntegrityDiscardconflictsParams(
    ApiForget,
):
    pass
