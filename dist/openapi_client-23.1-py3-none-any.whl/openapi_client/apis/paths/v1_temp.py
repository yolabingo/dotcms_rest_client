from openapi_client.paths.v1_temp.post import ApiForpost


class V1Temp(
    ApiForpost,
):
    pass
