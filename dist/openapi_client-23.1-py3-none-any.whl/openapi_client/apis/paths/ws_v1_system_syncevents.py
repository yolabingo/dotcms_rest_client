from openapi_client.paths.ws_v1_system_syncevents.get import ApiForget


class WsV1SystemSyncevents(
    ApiForget,
):
    pass
