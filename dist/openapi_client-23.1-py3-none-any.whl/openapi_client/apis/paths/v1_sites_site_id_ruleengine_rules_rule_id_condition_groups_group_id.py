from openapi_client.paths.v1_sites_site_id_ruleengine_rules_rule_id_condition_groups_group_id.get import ApiForget
from openapi_client.paths.v1_sites_site_id_ruleengine_rules_rule_id_condition_groups_group_id.put import ApiForput


class V1SitesSiteIdRuleengineRulesRuleIdConditionGroupsGroupId(
    ApiForget,
    ApiForput,
):
    pass
