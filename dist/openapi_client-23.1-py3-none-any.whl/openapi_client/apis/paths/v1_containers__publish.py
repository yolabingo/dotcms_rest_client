from openapi_client.paths.v1_containers__publish.put import ApiForput


class V1ContainersPublish(
    ApiForput,
):
    pass
