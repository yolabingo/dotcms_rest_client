from openapi_client.paths.v1_portlet_custom.post import ApiForpost


class V1PortletCustom(
    ApiForpost,
):
    pass
