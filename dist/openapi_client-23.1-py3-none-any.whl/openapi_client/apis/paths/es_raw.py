from openapi_client.paths.es_raw.get import ApiForget
from openapi_client.paths.es_raw.post import ApiForpost


class EsRaw(
    ApiForget,
    ApiForpost,
):
    pass
