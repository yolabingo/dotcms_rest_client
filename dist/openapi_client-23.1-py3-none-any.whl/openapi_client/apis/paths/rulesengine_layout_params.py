from openapi_client.paths.rulesengine_layout_params.get import ApiForget


class RulesengineLayoutParams(
    ApiForget,
):
    pass
