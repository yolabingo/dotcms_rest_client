from openapi_client.paths.v1_notification_delete.put import ApiForput


class V1NotificationDelete(
    ApiForput,
):
    pass
