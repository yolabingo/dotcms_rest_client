from openapi_client.paths.v1_notification_get_new_notifications_count.get import ApiForget


class V1NotificationGetNewNotificationsCount(
    ApiForget,
):
    pass
