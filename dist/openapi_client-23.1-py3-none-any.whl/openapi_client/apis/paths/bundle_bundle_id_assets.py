from openapi_client.paths.bundle_bundle_id_assets.get import ApiForget


class BundleBundleIdAssets(
    ApiForget,
):
    pass
