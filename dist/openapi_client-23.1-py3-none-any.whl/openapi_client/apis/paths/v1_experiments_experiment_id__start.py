from openapi_client.paths.v1_experiments_experiment_id__start.post import ApiForpost


class V1ExperimentsExperimentIdStart(
    ApiForpost,
):
    pass
