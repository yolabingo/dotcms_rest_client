from openapi_client.paths.v1_redis_incr_key.get import ApiForget
from openapi_client.paths.v1_redis_incr_key.put import ApiForput


class V1RedisIncrKey(
    ApiForget,
    ApiForput,
):
    pass
