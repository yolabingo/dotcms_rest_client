from openapi_client.paths.v1_site_site_id__unpublish.put import ApiForput


class V1SiteSiteIdUnpublish(
    ApiForput,
):
    pass
