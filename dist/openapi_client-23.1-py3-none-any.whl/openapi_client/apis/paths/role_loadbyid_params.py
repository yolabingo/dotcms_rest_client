from openapi_client.paths.role_loadbyid_params.get import ApiForget


class RoleLoadbyidParams(
    ApiForget,
):
    pass
