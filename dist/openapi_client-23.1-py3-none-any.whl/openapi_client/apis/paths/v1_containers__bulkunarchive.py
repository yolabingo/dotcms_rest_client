from openapi_client.paths.v1_containers__bulkunarchive.put import ApiForput


class V1ContainersBulkunarchive(
    ApiForput,
):
    pass
