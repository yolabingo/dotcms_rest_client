from openapi_client.paths.v1_sites_site_id_ruleengine_actions_action_id.get import ApiForget
from openapi_client.paths.v1_sites_site_id_ruleengine_actions_action_id.put import ApiForput
from openapi_client.paths.v1_sites_site_id_ruleengine_actions_action_id.delete import ApiFordelete


class V1SitesSiteIdRuleengineActionsActionId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
