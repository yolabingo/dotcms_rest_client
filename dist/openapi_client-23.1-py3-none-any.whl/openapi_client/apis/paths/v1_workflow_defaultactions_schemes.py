from openapi_client.paths.v1_workflow_defaultactions_schemes.get import ApiForget


class V1WorkflowDefaultactionsSchemes(
    ApiForget,
):
    pass
