from openapi_client.paths.v1_caches_provider_provider_object_group_id.get import ApiForget


class V1CachesProviderProviderObjectGroupId(
    ApiForget,
):
    pass
