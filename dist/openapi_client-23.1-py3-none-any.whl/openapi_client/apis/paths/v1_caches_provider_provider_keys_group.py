from openapi_client.paths.v1_caches_provider_provider_keys_group.get import ApiForget


class V1CachesProviderProviderKeysGroup(
    ApiForget,
):
    pass
