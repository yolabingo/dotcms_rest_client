from openapi_client.paths.application_wadl_path.get import ApiForget


class ApplicationWadlPath(
    ApiForget,
):
    pass
