from openapi_client.paths.v1_maintenance__download_db.get import ApiForget


class V1MaintenanceDownloadDb(
    ApiForget,
):
    pass
