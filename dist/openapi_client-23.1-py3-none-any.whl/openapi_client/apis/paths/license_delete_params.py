from openapi_client.paths.license_delete_params.delete import ApiFordelete


class LicenseDeleteParams(
    ApiFordelete,
):
    pass
