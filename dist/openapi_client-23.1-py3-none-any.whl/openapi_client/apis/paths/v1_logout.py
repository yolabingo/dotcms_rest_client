from openapi_client.paths.v1_logout.get import ApiForget


class V1Logout(
    ApiForget,
):
    pass
