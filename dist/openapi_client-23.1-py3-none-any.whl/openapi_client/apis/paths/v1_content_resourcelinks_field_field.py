from openapi_client.paths.v1_content_resourcelinks_field_field.get import ApiForget


class V1ContentResourcelinksFieldField(
    ApiForget,
):
    pass
