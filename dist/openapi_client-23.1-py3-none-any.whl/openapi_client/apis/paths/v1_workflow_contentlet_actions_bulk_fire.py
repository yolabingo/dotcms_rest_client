from openapi_client.paths.v1_workflow_contentlet_actions_bulk_fire.put import ApiForput


class V1WorkflowContentletActionsBulkFire(
    ApiForput,
):
    pass
