from openapi_client.paths.environment_loadenvironments_params.get import ApiForget


class EnvironmentLoadenvironmentsParams(
    ApiForget,
):
    pass
