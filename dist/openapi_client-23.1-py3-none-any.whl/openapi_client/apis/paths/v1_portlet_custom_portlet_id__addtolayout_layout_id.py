from openapi_client.paths.v1_portlet_custom_portlet_id__addtolayout_layout_id.put import ApiForput


class V1PortletCustomPortletIdAddtolayoutLayoutId(
    ApiForput,
):
    pass
