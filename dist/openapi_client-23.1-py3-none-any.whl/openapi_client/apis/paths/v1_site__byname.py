from openapi_client.paths.v1_site__byname.post import ApiForpost


class V1SiteByname(
    ApiForpost,
):
    pass
