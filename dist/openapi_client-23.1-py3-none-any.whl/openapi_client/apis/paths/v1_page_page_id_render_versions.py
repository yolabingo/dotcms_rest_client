from openapi_client.paths.v1_page_page_id_render_versions.get import ApiForget


class V1PagePageIdRenderVersions(
    ApiForget,
):
    pass
