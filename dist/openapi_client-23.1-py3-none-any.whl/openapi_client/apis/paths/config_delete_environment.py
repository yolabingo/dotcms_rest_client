from openapi_client.paths.config_delete_environment.post import ApiForpost


class ConfigDeleteEnvironment(
    ApiForpost,
):
    pass
