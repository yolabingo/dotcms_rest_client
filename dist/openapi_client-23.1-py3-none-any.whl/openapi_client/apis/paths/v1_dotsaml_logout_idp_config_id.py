from openapi_client.paths.v1_dotsaml_logout_idp_config_id.get import ApiForget
from openapi_client.paths.v1_dotsaml_logout_idp_config_id.post import ApiForpost


class V1DotsamlLogoutIdpConfigId(
    ApiForget,
    ApiForpost,
):
    pass
