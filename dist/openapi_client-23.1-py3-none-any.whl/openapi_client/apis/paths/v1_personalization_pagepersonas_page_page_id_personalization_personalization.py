from openapi_client.paths.v1_personalization_pagepersonas_page_page_id_personalization_personalization.delete import ApiFordelete


class V1PersonalizationPagepersonasPagePageIdPersonalizationPersonalization(
    ApiFordelete,
):
    pass
