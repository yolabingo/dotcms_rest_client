from openapi_client.paths.osgi__process_exports_bundle.get import ApiForget


class OsgiProcessExportsBundle(
    ApiForget,
):
    pass
