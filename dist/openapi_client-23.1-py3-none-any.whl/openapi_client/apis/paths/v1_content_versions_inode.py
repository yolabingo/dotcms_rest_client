from openapi_client.paths.v1_content_versions_inode.get import ApiForget


class V1ContentVersionsInode(
    ApiForget,
):
    pass
