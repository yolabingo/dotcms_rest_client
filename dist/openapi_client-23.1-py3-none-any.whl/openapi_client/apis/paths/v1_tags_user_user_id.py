from openapi_client.paths.v1_tags_user_user_id.get import ApiForget


class V1TagsUserUserId(
    ApiForget,
):
    pass
