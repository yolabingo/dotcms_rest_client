from openapi_client.paths.v2_languages_id_languageid.get import ApiForget


class V2LanguagesIdLanguageid(
    ApiForget,
):
    pass
