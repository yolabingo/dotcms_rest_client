from openapi_client.paths.v1_maintenance__download_log_file_name.get import ApiForget


class V1MaintenanceDownloadLogFileName(
    ApiForget,
):
    pass
