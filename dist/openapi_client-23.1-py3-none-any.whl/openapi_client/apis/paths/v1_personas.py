from openapi_client.paths.v1_personas.get import ApiForget


class V1Personas(
    ApiForget,
):
    pass
