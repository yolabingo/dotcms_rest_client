from openapi_client.paths.v1_redis_hash.put import ApiForput


class V1RedisHash(
    ApiForput,
):
    pass
