from openapi_client.paths.bundle__download_bundle_id.get import ApiForget


class BundleDownloadBundleId(
    ApiForget,
):
    pass
