from openapi_client.paths.v1_versionables_versionable_inode_or_identifier.get import ApiForget


class V1VersionablesVersionableInodeOrIdentifier(
    ApiForget,
):
    pass
