from openapi_client.paths.v1_notification_id_id.delete import ApiFordelete


class V1NotificationIdId(
    ApiFordelete,
):
    pass
