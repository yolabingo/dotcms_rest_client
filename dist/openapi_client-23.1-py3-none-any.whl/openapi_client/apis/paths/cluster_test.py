from openapi_client.paths.cluster_test.get import ApiForget


class ClusterTest(
    ApiForget,
):
    pass
