from openapi_client.paths.osgi.post import ApiForpost


class Osgi(
    ApiForpost,
):
    pass
