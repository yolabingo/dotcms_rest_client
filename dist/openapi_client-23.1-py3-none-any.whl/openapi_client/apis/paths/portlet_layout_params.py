from openapi_client.paths.portlet_layout_params.get import ApiForget


class PortletLayoutParams(
    ApiForget,
):
    pass
