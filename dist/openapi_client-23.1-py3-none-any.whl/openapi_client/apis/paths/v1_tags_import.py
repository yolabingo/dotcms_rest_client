from openapi_client.paths.v1_tags_import.post import ApiForpost


class V1TagsImport(
    ApiForpost,
):
    pass
