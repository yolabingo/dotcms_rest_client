from openapi_client.paths.v1_site_site_id.get import ApiForget
from openapi_client.paths.v1_site_site_id.delete import ApiFordelete


class V1SiteSiteId(
    ApiForget,
    ApiFordelete,
):
    pass
