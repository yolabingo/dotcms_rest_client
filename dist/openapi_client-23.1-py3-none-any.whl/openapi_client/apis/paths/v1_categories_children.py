from openapi_client.paths.v1_categories_children.get import ApiForget


class V1CategoriesChildren(
    ApiForget,
):
    pass
