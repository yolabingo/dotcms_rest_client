from openapi_client.paths.v1_site_default_site.get import ApiForget


class V1SiteDefaultSite(
    ApiForget,
):
    pass
