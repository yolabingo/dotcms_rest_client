from openapi_client.paths.v1_authentication.post import ApiForpost


class V1Authentication(
    ApiForpost,
):
    pass
