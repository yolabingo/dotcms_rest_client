from openapi_client.paths.v1_experiments.get import ApiForget
from openapi_client.paths.v1_experiments.post import ApiForpost


class V1Experiments(
    ApiForget,
    ApiForpost,
):
    pass
