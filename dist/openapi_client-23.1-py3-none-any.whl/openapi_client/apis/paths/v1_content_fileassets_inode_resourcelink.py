from openapi_client.paths.v1_content_fileassets_inode_resourcelink.get import ApiForget


class V1ContentFileassetsInodeResourcelink(
    ApiForget,
):
    pass
