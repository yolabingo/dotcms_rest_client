from openapi_client.paths.license_all_params.get import ApiForget


class LicenseAllParams(
    ApiForget,
):
    pass
