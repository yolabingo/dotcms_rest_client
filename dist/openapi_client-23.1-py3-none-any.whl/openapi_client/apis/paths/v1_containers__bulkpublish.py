from openapi_client.paths.v1_containers__bulkpublish.put import ApiForput


class V1ContainersBulkpublish(
    ApiForput,
):
    pass
