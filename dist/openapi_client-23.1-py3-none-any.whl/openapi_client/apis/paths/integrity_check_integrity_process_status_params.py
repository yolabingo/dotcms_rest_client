from openapi_client.paths.integrity_check_integrity_process_status_params.get import ApiForget


class IntegrityCheckIntegrityProcessStatusParams(
    ApiForget,
):
    pass
