from openapi_client.paths.v1_portlet_portlet_id_portlet_id_role_id_role_id.delete import ApiFordelete


class V1PortletPortletIdPortletIdRoleIdRoleId(
    ApiFordelete,
):
    pass
