from openapi_client.paths.v1_maintenance__shutdown.delete import ApiFordelete


class V1MaintenanceShutdown(
    ApiFordelete,
):
    pass
