from openapi_client.paths.v1_experiments_experiment_id_variants.post import ApiForpost


class V1ExperimentsExperimentIdVariants(
    ApiForpost,
):
    pass
