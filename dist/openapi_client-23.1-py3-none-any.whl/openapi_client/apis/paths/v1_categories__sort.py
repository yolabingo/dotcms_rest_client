from openapi_client.paths.v1_categories__sort.put import ApiForput


class V1CategoriesSort(
    ApiForput,
):
    pass
