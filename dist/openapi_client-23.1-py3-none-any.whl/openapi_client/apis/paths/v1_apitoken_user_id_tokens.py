from openapi_client.paths.v1_apitoken_user_id_tokens.get import ApiForget


class V1ApitokenUserIdTokens(
    ApiForget,
):
    pass
