from openapi_client.paths.v1_site_site_id__unarchive.put import ApiForput


class V1SiteSiteIdUnarchive(
    ApiForput,
):
    pass
