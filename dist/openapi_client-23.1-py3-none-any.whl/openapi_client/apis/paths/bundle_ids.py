from openapi_client.paths.bundle_ids.delete import ApiFordelete


class BundleIds(
    ApiFordelete,
):
    pass
