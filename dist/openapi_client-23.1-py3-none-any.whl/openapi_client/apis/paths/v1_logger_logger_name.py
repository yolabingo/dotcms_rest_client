from openapi_client.paths.v1_logger_logger_name.get import ApiForget


class V1LoggerLoggerName(
    ApiForget,
):
    pass
