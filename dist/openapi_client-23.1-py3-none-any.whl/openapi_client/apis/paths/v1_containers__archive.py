from openapi_client.paths.v1_containers__archive.put import ApiForput


class V1ContainersArchive(
    ApiForput,
):
    pass
