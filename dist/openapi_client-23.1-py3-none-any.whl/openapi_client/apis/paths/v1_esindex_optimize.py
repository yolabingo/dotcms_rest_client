from openapi_client.paths.v1_esindex_optimize.post import ApiForpost


class V1EsindexOptimize(
    ApiForpost,
):
    pass
