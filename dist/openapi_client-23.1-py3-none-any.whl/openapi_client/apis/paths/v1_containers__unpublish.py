from openapi_client.paths.v1_containers__unpublish.put import ApiForput


class V1ContainersUnpublish(
    ApiForput,
):
    pass
