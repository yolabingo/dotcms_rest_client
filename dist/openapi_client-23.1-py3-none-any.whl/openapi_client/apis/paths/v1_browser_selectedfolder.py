from openapi_client.paths.v1_browser_selectedfolder.get import ApiForget
from openapi_client.paths.v1_browser_selectedfolder.put import ApiForput


class V1BrowserSelectedfolder(
    ApiForget,
    ApiForput,
):
    pass
