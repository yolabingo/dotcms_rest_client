from openapi_client.paths.bundle_all.delete import ApiFordelete


class BundleAll(
    ApiFordelete,
):
    pass
