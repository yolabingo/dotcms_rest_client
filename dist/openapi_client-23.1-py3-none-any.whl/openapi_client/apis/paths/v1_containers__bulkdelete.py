from openapi_client.paths.v1_containers__bulkdelete.delete import ApiFordelete


class V1ContainersBulkdelete(
    ApiFordelete,
):
    pass
