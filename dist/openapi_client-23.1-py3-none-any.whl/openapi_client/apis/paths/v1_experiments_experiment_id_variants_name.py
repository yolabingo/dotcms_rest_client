from openapi_client.paths.v1_experiments_experiment_id_variants_name.delete import ApiFordelete


class V1ExperimentsExperimentIdVariantsName(
    ApiFordelete,
):
    pass
