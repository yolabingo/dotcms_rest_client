from openapi_client.paths.v1_roles.get import ApiForget


class V1Roles(
    ApiForget,
):
    pass
