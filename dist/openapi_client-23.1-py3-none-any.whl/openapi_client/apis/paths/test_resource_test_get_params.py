from openapi_client.paths.test_resource_test_get_params.get import ApiForget


class TestResourceTestGetParams(
    ApiForget,
):
    pass
