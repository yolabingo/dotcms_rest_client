from openapi_client.paths.v1_workflow_actions_fire.put import ApiForput


class V1WorkflowActionsFire(
    ApiForput,
):
    pass
