from openapi_client.paths.v2_languages_language__makedefault.put import ApiForput


class V2LanguagesLanguageMakedefault(
    ApiForput,
):
    pass
