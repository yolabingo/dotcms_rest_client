from openapi_client.paths.v1_page_page_id_content_tree.get import ApiForget


class V1PagePageIdContentTree(
    ApiForget,
):
    pass
