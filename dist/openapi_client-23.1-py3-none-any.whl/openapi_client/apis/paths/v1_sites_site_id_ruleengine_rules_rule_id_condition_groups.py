from openapi_client.paths.v1_sites_site_id_ruleengine_rules_rule_id_condition_groups.get import ApiForget
from openapi_client.paths.v1_sites_site_id_ruleengine_rules_rule_id_condition_groups.post import ApiForpost


class V1SitesSiteIdRuleengineRulesRuleIdConditionGroups(
    ApiForget,
    ApiForpost,
):
    pass
