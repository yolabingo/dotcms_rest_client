from openapi_client.paths.content_indexsearch_query_sortby_sortby_limit_limit_offset_offset.get import ApiForget


class ContentIndexsearchQuerySortbySortbyLimitLimitOffsetOffset(
    ApiForget,
):
    pass
