from openapi_client.paths.v1_pushpublish_filters.get import ApiForget
from openapi_client.paths.v1_pushpublish_filters.put import ApiForput
from openapi_client.paths.v1_pushpublish_filters.post import ApiForpost


class V1PushpublishFilters(
    ApiForget,
    ApiForput,
    ApiForpost,
):
    pass
