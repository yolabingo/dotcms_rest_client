from openapi_client.paths.v1_page_json_uri.get import ApiForget


class V1PageJsonUri(
    ApiForget,
):
    pass
