from openapi_client.paths.v1_site_switch.put import ApiForput


class V1SiteSwitch(
    ApiForput,
):
    pass
