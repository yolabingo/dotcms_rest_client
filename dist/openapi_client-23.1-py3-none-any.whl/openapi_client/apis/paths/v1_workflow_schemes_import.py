from openapi_client.paths.v1_workflow_schemes_import.post import ApiForpost


class V1WorkflowSchemesImport(
    ApiForpost,
):
    pass
