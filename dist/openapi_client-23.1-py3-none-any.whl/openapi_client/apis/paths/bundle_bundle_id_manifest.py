from openapi_client.paths.bundle_bundle_id_manifest.get import ApiForget


class BundleBundleIdManifest(
    ApiForget,
):
    pass
