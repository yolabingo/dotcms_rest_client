from openapi_client.paths.v1_publishqueue.delete import ApiFordelete


class V1Publishqueue(
    ApiFordelete,
):
    pass
