from openapi_client.paths.portlet_params.get import ApiForget
from openapi_client.paths.portlet_params.post import ApiForpost


class PortletParams(
    ApiForget,
    ApiForpost,
):
    pass
