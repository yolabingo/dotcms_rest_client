from openapi_client.paths.v1_templates__unpublish.put import ApiForput


class V1TemplatesUnpublish(
    ApiForput,
):
    pass
