from openapi_client.paths.v1_contenttype_basetypes.get import ApiForget


class V1ContenttypeBasetypes(
    ApiForget,
):
    pass
