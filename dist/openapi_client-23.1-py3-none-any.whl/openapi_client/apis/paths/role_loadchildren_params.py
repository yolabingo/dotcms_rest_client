from openapi_client.paths.role_loadchildren_params.get import ApiForget


class RoleLoadchildrenParams(
    ApiForget,
):
    pass
