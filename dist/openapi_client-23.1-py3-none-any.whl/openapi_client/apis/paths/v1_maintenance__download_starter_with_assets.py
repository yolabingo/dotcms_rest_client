from openapi_client.paths.v1_maintenance__download_starter_with_assets.get import ApiForget


class V1MaintenanceDownloadStarterWithAssets(
    ApiForget,
):
    pass
