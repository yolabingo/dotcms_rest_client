from openapi_client.paths.v1_templates__savepublish.put import ApiForput


class V1TemplatesSavepublish(
    ApiForput,
):
    pass
