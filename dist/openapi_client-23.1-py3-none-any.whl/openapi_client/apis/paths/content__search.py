from openapi_client.paths.content__search.post import ApiForpost


class ContentSearch(
    ApiForpost,
):
    pass
