from openapi_client.paths.v1_configuration__validate_company_email.post import ApiForpost


class V1ConfigurationValidateCompanyEmail(
    ApiForpost,
):
    pass
