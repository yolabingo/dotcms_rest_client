from openapi_client.paths.v1_apitoken_token_id.delete import ApiFordelete


class V1ApitokenTokenId(
    ApiFordelete,
):
    pass
