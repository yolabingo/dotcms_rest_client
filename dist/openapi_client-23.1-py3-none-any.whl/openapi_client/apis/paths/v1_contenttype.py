from openapi_client.paths.v1_contenttype.get import ApiForget
from openapi_client.paths.v1_contenttype.post import ApiForpost


class V1Contenttype(
    ApiForget,
    ApiForpost,
):
    pass
