from openapi_client.paths.v1_relationships_cardinalities.get import ApiForget


class V1RelationshipsCardinalities(
    ApiForget,
):
    pass
