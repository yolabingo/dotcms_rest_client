from openapi_client.paths.config_save_company_basic_info.post import ApiForpost


class ConfigSaveCompanyBasicInfo(
    ApiForpost,
):
    pass
