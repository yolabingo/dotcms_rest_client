from openapi_client.paths.v1_folder_sitename_site_name_uri_uri.get import ApiForget


class V1FolderSitenameSiteNameUriUri(
    ApiForget,
):
    pass
