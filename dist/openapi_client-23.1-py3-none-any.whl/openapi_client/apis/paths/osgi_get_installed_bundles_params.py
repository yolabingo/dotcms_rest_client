from openapi_client.paths.osgi_get_installed_bundles_params.get import ApiForget


class OsgiGetInstalledBundlesParams(
    ApiForget,
):
    pass
