from openapi_client.paths.license_upload_params.post import ApiForpost


class LicenseUploadParams(
    ApiForpost,
):
    pass
