from openapi_client.paths.v2_languages.get import ApiForget
from openapi_client.paths.v2_languages.post import ApiForpost


class V2Languages(
    ApiForget,
    ApiForpost,
):
    pass
