from openapi_client.paths.v2_languages_language_keys.get import ApiForget


class V2LanguagesLanguageKeys(
    ApiForget,
):
    pass
