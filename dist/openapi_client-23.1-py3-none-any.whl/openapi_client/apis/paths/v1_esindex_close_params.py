from openapi_client.paths.v1_esindex_close_params.put import ApiForput


class V1EsindexCloseParams(
    ApiForput,
):
    pass
