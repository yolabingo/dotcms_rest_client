from openapi_client.paths.v1_workflow_reorder_steps_step_id_actions_action_id.put import ApiForput


class V1WorkflowReorderStepsStepIdActionsActionId(
    ApiForput,
):
    pass
