from openapi_client.paths.v1_folder_folder_id.get import ApiForget


class V1FolderFolderId(
    ApiForget,
):
    pass
