from openapi_client.paths.license_apply_license.post import ApiForpost


class LicenseApplyLicense(
    ApiForpost,
):
    pass
