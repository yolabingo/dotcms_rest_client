from openapi_client.paths.v1_workflow_schemes_scheme_id_copy.post import ApiForpost


class V1WorkflowSchemesSchemeIdCopy(
    ApiForpost,
):
    pass
