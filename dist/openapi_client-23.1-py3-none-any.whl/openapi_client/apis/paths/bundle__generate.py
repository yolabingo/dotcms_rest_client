from openapi_client.paths.bundle__generate.post import ApiForpost


class BundleGenerate(
    ApiForpost,
):
    pass
