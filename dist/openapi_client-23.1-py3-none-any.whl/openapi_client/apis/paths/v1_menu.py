from openapi_client.paths.v1_menu.get import ApiForget


class V1Menu(
    ApiForget,
):
    pass
