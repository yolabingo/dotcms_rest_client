from openapi_client.paths.v1_page_layout.post import ApiForpost


class V1PageLayout(
    ApiForpost,
):
    pass
