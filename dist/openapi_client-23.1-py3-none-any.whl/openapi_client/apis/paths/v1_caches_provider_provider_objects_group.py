from openapi_client.paths.v1_caches_provider_provider_objects_group.get import ApiForget


class V1CachesProviderProviderObjectsGroup(
    ApiForget,
):
    pass
