from openapi_client.paths.v1_content_resourcelinks.get import ApiForget


class V1ContentResourcelinks(
    ApiForget,
):
    pass
