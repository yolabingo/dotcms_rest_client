from openapi_client.paths.v1_pushpublish_filters_filter_key.get import ApiForget
from openapi_client.paths.v1_pushpublish_filters_filter_key.delete import ApiFordelete


class V1PushpublishFiltersFilterKey(
    ApiForget,
    ApiFordelete,
):
    pass
