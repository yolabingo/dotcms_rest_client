from openapi_client.paths.v1_maintenance__pg_dump_available.get import ApiForget


class V1MaintenancePgDumpAvailable(
    ApiForget,
):
    pass
