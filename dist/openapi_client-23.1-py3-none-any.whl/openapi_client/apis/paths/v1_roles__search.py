from openapi_client.paths.v1_roles__search.get import ApiForget


class V1RolesSearch(
    ApiForget,
):
    pass
