from openapi_client.paths.v1_esindex_cluster.get import ApiForget


class V1EsindexCluster(
    ApiForget,
):
    pass
