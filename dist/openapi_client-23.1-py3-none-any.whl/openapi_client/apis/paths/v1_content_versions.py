from openapi_client.paths.v1_content_versions.get import ApiForget


class V1ContentVersions(
    ApiForget,
):
    pass
