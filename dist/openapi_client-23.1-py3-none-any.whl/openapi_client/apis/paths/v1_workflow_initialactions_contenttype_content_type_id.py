from openapi_client.paths.v1_workflow_initialactions_contenttype_content_type_id.get import ApiForget


class V1WorkflowInitialactionsContenttypeContentTypeId(
    ApiForget,
):
    pass
