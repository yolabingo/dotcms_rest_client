from openapi_client.paths.bundle_publisher_publish.post import ApiForpost


class BundlePublisherPublish(
    ApiForpost,
):
    pass
