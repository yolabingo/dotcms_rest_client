from openapi_client.paths.v1_workflow_contentlet_actions__bulkfire.post import ApiForpost


class V1WorkflowContentletActionsBulkfire(
    ApiForpost,
):
    pass
