from openapi_client.paths.widget_params.get import ApiForget


class WidgetParams(
    ApiForget,
):
    pass
