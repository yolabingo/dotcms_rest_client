from openapi_client.paths.v1_site__copy.put import ApiForput


class V1SiteCopy(
    ApiForput,
):
    pass
