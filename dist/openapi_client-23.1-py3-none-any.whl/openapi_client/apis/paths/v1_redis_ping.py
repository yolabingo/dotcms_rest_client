from openapi_client.paths.v1_redis_ping.get import ApiForget


class V1RedisPing(
    ApiForget,
):
    pass
