from openapi_client.paths.cluster_license_repo_status.get import ApiForget


class ClusterLicenseRepoStatus(
    ApiForget,
):
    pass
