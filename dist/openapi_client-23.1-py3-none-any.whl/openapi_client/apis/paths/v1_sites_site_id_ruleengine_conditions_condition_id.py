from openapi_client.paths.v1_sites_site_id_ruleengine_conditions_condition_id.get import ApiForget
from openapi_client.paths.v1_sites_site_id_ruleengine_conditions_condition_id.put import ApiForput
from openapi_client.paths.v1_sites_site_id_ruleengine_conditions_condition_id.delete import ApiFordelete


class V1SitesSiteIdRuleengineConditionsConditionId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
