from openapi_client.paths.config_delete_endpoint.post import ApiForpost


class ConfigDeleteEndpoint(
    ApiForpost,
):
    pass
