from openapi_client.paths.bundle_deletepushhistory_params.get import ApiForget


class BundleDeletepushhistoryParams(
    ApiForget,
):
    pass
