from openapi_client.paths.v1_browsertree_sitename_sitename_uri_uri.get import ApiForget


class V1BrowsertreeSitenameSitenameUriUri(
    ApiForget,
):
    pass
