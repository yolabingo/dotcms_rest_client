from openapi_client.paths.v1_esindex_failed.get import ApiForget
from openapi_client.paths.v1_esindex_failed.delete import ApiFordelete


class V1EsindexFailed(
    ApiForget,
    ApiFordelete,
):
    pass
