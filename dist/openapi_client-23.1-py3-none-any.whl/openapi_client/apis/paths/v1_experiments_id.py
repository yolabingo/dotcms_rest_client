from openapi_client.paths.v1_experiments_id.get import ApiForget


class V1ExperimentsId(
    ApiForget,
):
    pass
