from openapi_client.paths.v1_contenttype_type_id_fields_id_field_id_variables_id_field_var_id.get import ApiForget
from openapi_client.paths.v1_contenttype_type_id_fields_id_field_id_variables_id_field_var_id.put import ApiForput
from openapi_client.paths.v1_contenttype_type_id_fields_id_field_id_variables_id_field_var_id.delete import ApiFordelete


class V1ContenttypeTypeIdFieldsIdFieldIdVariablesIdFieldVarId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
