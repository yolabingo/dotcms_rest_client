from openapi_client.paths.v1_caches_providers_group.get import ApiForget


class V1CachesProvidersGroup(
    ApiForget,
):
    pass
