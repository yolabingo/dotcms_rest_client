from openapi_client.paths.v1_apitoken_remote.put import ApiForput


class V1ApitokenRemote(
    ApiForput,
):
    pass
