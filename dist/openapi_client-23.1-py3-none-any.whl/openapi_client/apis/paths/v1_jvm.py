from openapi_client.paths.v1_jvm.get import ApiForget


class V1Jvm(
    ApiForget,
):
    pass
