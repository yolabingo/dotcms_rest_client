from openapi_client.paths.v1_esindex_activate_params.put import ApiForput


class V1EsindexActivateParams(
    ApiForput,
):
    pass
