from openapi_client.paths.v1_containers__bulkunpublish.put import ApiForput


class V1ContainersBulkunpublish(
    ApiForput,
):
    pass
