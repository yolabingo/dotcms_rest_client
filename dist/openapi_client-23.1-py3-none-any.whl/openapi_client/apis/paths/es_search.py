from openapi_client.paths.es_search.get import ApiForget
from openapi_client.paths.es_search.post import ApiForpost


class EsSearch(
    ApiForget,
    ApiForpost,
):
    pass
