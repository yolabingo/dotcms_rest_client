from openapi_client.paths.v1_maintenance__download_starter.get import ApiForget


class V1MaintenanceDownloadStarter(
    ApiForget,
):
    pass
