from openapi_client.paths.v1_apitoken_users_userid_revoke.put import ApiForput


class V1ApitokenUsersUseridRevoke(
    ApiForput,
):
    pass
