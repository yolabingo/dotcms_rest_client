from openapi_client.paths.v1_roles_roleid_rolehierarchyanduserroles.get import ApiForget


class V1RolesRoleidRolehierarchyanduserroles(
    ApiForget,
):
    pass
