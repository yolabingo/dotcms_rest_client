from openapi_client.paths.v1_personalization_pagepersonas.post import ApiForpost


class V1PersonalizationPagepersonas(
    ApiForpost,
):
    pass
